from django.apps import AppConfig


class QnaConfig(AppConfig):
    name = 'qna'
